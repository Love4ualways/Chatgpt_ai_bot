package com.example.alphapulseresearch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private const val REFRESH_MS = 5_000L
private const val TOKEN_LIST_URL =
    "https://www.binance.com/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list"

data class AlphaToken(
    val tokenId: String,
    val symbol: String,
    val name: String,
    val alphaId: String,
    val chainName: String,
    val listingTime: Long,
    val priceHigh24h: Double?,
    val priceLow24h: Double?,
    val tradeCount24h: Double?,
    val score: Int?,
    val offline: Boolean
) {
    val rangePct: Double?
        get() {
            val high = priceHigh24h ?: return null
            val low = priceLow24h ?: return null
            if (low <= 0.0 || high < low) return null
            return (high - low) / low * 100.0
        }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlphaPulseApp() }
    }
}

@Composable
private fun AlphaPulseApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var tokens by remember { mutableStateOf<List<AlphaToken>>(emptyList()) }
    var status by remember { mutableStateOf("Connecting to Binance Alpha…") }
    var lastUpdated by remember { mutableStateOf("Not updated yet") }
    var isLoading by remember { mutableStateOf(false) }
    var refreshCounter by remember { mutableIntStateOf(0) }
    val knownIds = remember { mutableStateSetOf<String>() }
    var firstLoad by remember { mutableStateOf(true) }
    var newSinceLastCheck by remember { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(refreshCounter) {
        while (true) {
            isLoading = true
            try {
                val result = withContext(Dispatchers.IO) { fetchAlphaTokens() }
                val currentIds = result.map { it.tokenId }.filter { it.isNotBlank() }.toSet()
                if (firstLoad) {
                    knownIds.addAll(currentIds)
                    firstLoad = false
                    newSinceLastCheck = emptySet()
                } else {
                    newSinceLastCheck = currentIds - knownIds
                    knownIds.addAll(currentIds)
                }
                tokens = result.sortedByDescending { it.listingTime }
                status = if (result.isEmpty()) {
                    "No tokens returned by the API"
                } else {
                    "Live data connected · ${result.size} Alpha tokens"
                }
                lastUpdated = DateFormat.getDateTimeInstance(
                    DateFormat.SHORT, DateFormat.MEDIUM, Locale.getDefault()
                ).format(Date())
            } catch (e: Exception) {
                status = "Data unavailable: ${e.message ?: "request failed"}"
            } finally {
                isLoading = false
            }
            delay(REFRESH_MS)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text("ALPHA PULSE", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Binance Alpha research dashboard", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(status, style = MaterialTheme.typography.bodySmall)
                    Text("Last update: $lastUpdated · refresh target: 5 sec", style = MaterialTheme.typography.labelSmall)
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Text("NEW") },
                        label = { Text("New Alpha Coins") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Text("SCAN") },
                        label = { Text("Pre-Pump Research") }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
                if (isLoading && tokens.isEmpty()) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                if (selectedTab == 0) {
                    NewAlphaScreen(tokens, newSinceLastCheck)
                } else {
                    PrePumpResearchScreen(tokens)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Research only. Unusual activity is not a prediction of future price movement. Data may be delayed or unavailable.",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun NewAlphaScreen(tokens: List<AlphaToken>, newIds: Set<String>) {
    val recentlyListed = tokens.filter { it.listingTime > 0L }
        .sortedByDescending { it.listingTime }
    Column {
        Text("New Alpha Coins", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(
            if (newIds.isEmpty()) "Newly listed tokens are ordered by Binance listing time."
            else "${newIds.size} token(s) newly detected since the previous refresh.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        if (recentlyListed.isEmpty()) {
            EmptyState("No Alpha token records available yet. Check connection and try again.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recentlyListed, key = { it.tokenId }) { token ->
                    TokenCard(token = token, isNew = newIds.contains(token.tokenId))
                }
            }
        }
    }
}

@Composable
private fun PrePumpResearchScreen(tokens: List<AlphaToken>) {
    val candidates = tokens
        .filter { !it.offline && (it.tradeCount24h != null || it.rangePct != null) }
        .sortedWith(
            compareByDescending<AlphaToken> { it.tradeCount24h ?: -1.0 }
                .thenByDescending { it.rangePct ?: -1.0 }
        )
    Column {
        Text("Pre-Pump Research", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(
            "Activity watchlist, not a pump prediction. Sorted by available 24h trade count, with price range shown when supplied.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        if (candidates.isEmpty()) {
            EmptyState("No usable activity fields returned by Binance Alpha.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(candidates.take(100), key = { it.tokenId }) { token ->
                    TokenCard(token = token, isNew = false, research = true)
                }
            }
        }
    }
}

@Composable
private fun TokenCard(token: AlphaToken, isNew: Boolean, research: Boolean = false) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        token.symbol.ifBlank { token.alphaId.ifBlank { "Unknown token" } },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text("${token.name} · ${token.chainName}", style = MaterialTheme.typography.bodySmall)
                }
                if (isNew) {
                    AssistChip(onClick = {}, label = { Text("NEW") })
                } else if (token.offline) {
                    AssistChip(onClick = {}, label = { Text("OFFLINE") })
                }
            }
            Spacer(Modifier.height(4.dp))
            Text("Alpha ID: ${token.alphaId.ifBlank { "N/A" }}", style = MaterialTheme.typography.bodySmall)
            Text("Listed: ${formatTime(token.listingTime)}", style = MaterialTheme.typography.bodySmall)
            if (research) {
                Text("24h trades: ${formatNumber(token.tradeCount24h)}", style = MaterialTheme.typography.bodyMedium)
                Text("24h high/low range: ${token.rangePct?.let { String.format(Locale.US, "%.2f%%", it) } ?: "N/A"}",
                    style = MaterialTheme.typography.bodyMedium)
                Text("Binance score field: ${token.score?.toString() ?: "N/A"} (not a forecast)",
                    style = MaterialTheme.typography.labelSmall)
            } else {
                Text("24h trades: ${formatNumber(token.tradeCount24h)}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}

private suspend fun fetchAlphaTokens(): List<AlphaToken> = withContext(Dispatchers.IO) {
    val connection = (URL(TOKEN_LIST_URL).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 7_000
        readTimeout = 7_000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "AlphaPulseResearch/1.0 Android")
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("HTTP $code")
        val root = JSONObject(body)
        val data = root.optJSONArray("data")
            ?: root.optJSONObject("data")?.optJSONArray("tokens")
            ?: JSONArray()
        buildList {
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i) ?: continue
                val tokenId = item.optString("tokenId", "")
                val alphaId = item.optString("alphaId", "")
                if (tokenId.isBlank() && alphaId.isBlank()) continue
                add(
                    AlphaToken(
                        tokenId = tokenId.ifBlank { alphaId },
                        symbol = item.optString("symbol", item.optString("tokenSymbol", "")),
                        name = item.optString("name", item.optString("tokenName", "")),
                        alphaId = alphaId,
                        chainName = item.optString("chainName", "Unknown chain"),
                        listingTime = item.optLong("listingTime", 0L),
                        priceHigh24h = item.optString("priceHigh24h", "").toDoubleOrNull(),
                        priceLow24h = item.optString("priceLow24h", "").toDoubleOrNull(),
                        tradeCount24h = item.optString("count24h", "").toDoubleOrNull(),
                        score = if (item.has("score")) item.optInt("score") else null,
                        offline = item.optBoolean("offline", false)
                    )
                )
            }
        }
    } finally {
        connection.disconnect()
    }
}

private fun formatTime(timestamp: Long): String {
    if (timestamp <= 0L) return "Not provided"
    return DateFormat.getDateTimeInstance(
        DateFormat.SHORT, DateFormat.SHORT, Locale.getDefault()
    ).format(Date(timestamp))
}

private fun formatNumber(value: Double?): String {
    if (value == null) return "N/A"
    return if (value >= 1_000_000) String.format(Locale.US, "%.2fM", value / 1_000_000)
    else if (value >= 1_000) String.format(Locale.US, "%.1fK", value / 1_000)
    else String.format(Locale.US, "%.0f", value)
}
