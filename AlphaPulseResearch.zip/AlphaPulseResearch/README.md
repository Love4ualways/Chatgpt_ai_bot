# Alpha Pulse Research (Android)

An Android Studio starter project for a **research-only Binance Alpha dashboard**.

## Features

- Fetches Binance Alpha's public token-list endpoint.
- Polls every 5 seconds while the app is open.
- Separate **New Alpha Coins** and **Pre-Pump Research** tabs.
- Highlights token IDs first seen after the initial successful fetch.
- Orders token records by Binance `listingTime`.
- Displays available 24-hour trade count, high/low range, chain, and Binance-provided score field.
- Shows connection errors rather than generating fake token data.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Important limitations

- This starter app does **not** predict a future pump. The Pre-Pump Research tab is an activity watchlist sorted by the available 24-hour trade count; this is not a predictive model.
- The token-list endpoint may not expose every field consistently and Binance may change access policies, response schemas, rate limits, or availability.
- A 5-second polling interval is a target while the app is open. It does not guarantee a new listing is published or detected within five seconds.
- This app does not place orders or include a rapid-buy action.
- The app has not been built or tested against live Binance responses in this generated environment. Verify the API response and build in Android Studio/GitHub Actions before relying on it.
- Public token-list data alone is not enough to train or validate a reliable price prediction model.

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Extract this ZIP and upload the **contents** of the `AlphaPulseResearch` folder to the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Android APK**, or push a commit to `main`/`master`.
5. Open the completed workflow run and download the `alpha-pulse-research-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Build locally

Requirements: Android Studio with Android SDK 35, JDK 17, and Gradle 8.9.

From the project root:

```bash
gradle assembleDebug
```

The APK should be created at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## API source

The app uses Binance's documented Alpha token list:

`https://www.binance.com/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list`

Documentation:
https://developers.binance.com/en/docs/catalog/advanced-trading-alpha-trading/api/rest-api/market-data

## Next engineering steps

- Verify the actual response schema on-device and adjust the parser if needed.
- Add Binance Alpha ticker/klines data after confirming API access and rate limits.
- Add persistent point-in-time snapshots and outcome logging.
- Train and evaluate any future model only on real, timestamped historical observations with chronological holdout tests.
