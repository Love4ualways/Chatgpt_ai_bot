import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() => runApp(const AlphaMonitorApp());

class WatchItem {
  final String chain;
  final String address;
  final String symbol;
  final String? pool;
  WatchItem({required this.chain, required this.address, required this.symbol, this.pool});
  Map<String,dynamic> toJson()=>{'chain':chain,'address':address,'symbol':symbol,'pool':pool};
  factory WatchItem.fromJson(Map<String,dynamic> j)=>WatchItem(
    chain:j['chain']??'BSC', address:j['address']??'', symbol:j['symbol']??'TOKEN', pool:j['pool']);
}

class Activity {
  final DateTime time;
  final String title;
  final String detail;
  final String level;
  Activity(this.time,this.title,this.detail,this.level);
}

class MonitorService {
  WebSocketChannel? _ws;
  Timer? _timer;
  final void Function(Activity) onActivity;
  final void Function(String) onStatus;
  MonitorService(this.onActivity,this.onStatus);

  void stop() { _timer?.cancel(); _ws?.sink.close(); _ws=null; }

  Future<void> monitorBsc(WatchItem item, String rpc, String wsUrl) async {
    stop(); onStatus('BSC: connecting…');
    try {
      _ws = WebSocketChannel.connect(Uri.parse(wsUrl));
      int id=1;
      _ws!.sink.add(jsonEncode({
        'jsonrpc':'2.0','id':id++,'method':'eth_subscribe',
        'params':['logs', {'address': item.address}]
      }));
      _ws!.stream.listen((raw){
        try {
          final j=jsonDecode(raw);
          if(j['method']=='eth_subscription'){
            final r=j['params']['result'];
            final topics=(r['topics'] as List?)?.map((e)=>e.toString()).toList()??[];
            final sig = topics.isNotEmpty ? topics[0] : '';
            onActivity(Activity(DateTime.now(),'Contract activity',
              'New log in ${item.symbol}; tx ${r['transactionHash']}', 'info'));
            if(sig.toLowerCase().startsWith('0xddf252ad')){
              onActivity(Activity(DateTime.now(),'Transfer detected',
                'Token transfer event observed for ${item.symbol}.', 'info'));
            }
          }
        } catch(_){}
      }, onError: (_)=>onStatus('BSC WebSocket error'));
      onStatus('BSC: watching contract logs');
    } catch(e){ onStatus('BSC connection failed: $e'); }
  }

  Future<void> monitorSolana(WatchItem item, String wsUrl) async {
    stop(); onStatus('Solana: connecting…');
    try {
      _ws = WebSocketChannel.connect(Uri.parse(wsUrl));
      _ws!.sink.add(jsonEncode({
        'jsonrpc':'2.0','id':1,'method':'logsSubscribe',
        'params':[{'mentions':[item.address]}, {'commitment':'confirmed'}]
      }));
      _ws!.stream.listen((raw){
        try {
          final j=jsonDecode(raw);
          if(j['method']=='logsNotification'){
            final v=j['params']['result']['value'];
            final sig=j['params']['result']['value']['signature'];
            final err=v['err'];
            onActivity(Activity(DateTime.now(),'Solana transaction',
              '${item.symbol} mentioned • ${err==null?'success':'failed'} • $sig',
              err==null?'info':'warn'));
          }
        } catch(_){}
      }, onError: (_)=>onStatus('Solana WebSocket error'));
      onStatus('Solana: watching address mentions');
    } catch(e){ onStatus('Solana connection failed: $e'); }
  }
}

class AlphaMonitorApp extends StatefulWidget {
  const AlphaMonitorApp({super.key});
  @override State<AlphaMonitorApp> createState()=>_AlphaMonitorAppState();
}

class _AlphaMonitorAppState extends State<AlphaMonitorApp> {
  final address = TextEditingController();
  final symbol = TextEditingController(text:'TOKEN');
  final pool = TextEditingController();
  String chain='BSC';
  String status='Idle';
  final activities=<Activity>[];
  final items=<WatchItem>[];
  MonitorService? service;
  String bscRpc='https://bsc-dataseed.bnbchain.org';
  String bscWs='wss://bsc-ws-node.nariox.org:443';
  String solWs='wss://api.mainnet-beta.solana.com/';

  @override void initState(){super.initState(); load();}
  @override void dispose(){service?.stop(); address.dispose();symbol.dispose();pool.dispose();super.dispose();}

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    final raw=p.getStringList('watchlist')??[];
    setState(()=>items.addAll(raw.map((x)=>WatchItem.fromJson(jsonDecode(x)))));
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setStringList('watchlist',items.map((x)=>jsonEncode(x.toJson())).toList());
  }
  void add() {
    if(address.text.trim().isEmpty) return;
    setState(()=>items.insert(0,WatchItem(chain:chain,address:address.text.trim(),symbol:symbol.text.trim().isEmpty?'TOKEN':symbol.text.trim(),pool:pool.text.trim().isEmpty?null:pool.text.trim())));
    save(); address.clear(); pool.clear();
  }
  void start(WatchItem item) {
    service?.stop();
    service=MonitorService((a)=>setState(()=>activities.insert(0,a)),(s)=>setState(()=>status=s));
    if(item.chain=='BSC') service!.monitorBsc(item,bscRpc,bscWs);
    else service!.monitorSolana(item,solWs);
  }
  Color levelColor(String l) => l=='warn'?Colors.orange:Colors.green;

  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,
    theme:ThemeData(colorSchemeSeed:Colors.indigo,brightness:Brightness.dark,useMaterial3:true),
    home:Scaffold(
      appBar:AppBar(title:const Text('Alpha Chain Monitor'),actions:[
        IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'Alpha Chain Monitor',applicationVersion:'1.0.0',children:[
          const Text('Read-only blockchain activity monitor. It does not place orders or connect to wallets.')
        ]),icon:const Icon(Icons.info_outline))
      ]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Watch a token before exchange listing',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('Paste a BSC token contract or Solana mint. The app watches on-chain activity and helps distinguish a live contract from actual transaction activity.'),
          const SizedBox(height:14),
          SegmentedButton<String>(segments:const [
            ButtonSegment(value:'BSC',label:Text('BSC')),
            ButtonSegment(value:'SOL',label:Text('Solana')),
          ],selected:{chain},onSelectionChanged:(s)=>setState(()=>chain=s.first)),
          const SizedBox(height:12),
          TextField(controller:symbol,decoration:const InputDecoration(labelText:'Symbol',border:OutlineInputBorder())),
          const SizedBox(height:10),
          TextField(controller:address,decoration:InputDecoration(labelText:chain=='BSC'?'Token contract address':'Solana mint address',border:const OutlineInputBorder())),
          const SizedBox(height:10),
          if(chain=='BSC') TextField(controller:pool,decoration:const InputDecoration(labelText:'Optional liquidity-pool address',border:OutlineInputBorder())),
          const SizedBox(height:12),
          FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Add to watchlist'))
        ]))),
        const SizedBox(height:10),
        Card(child:ListTile(
          leading:Icon(status.contains('error')||status.contains('failed')?Icons.error_outline:Icons.radar),
          title:Text(status),
          subtitle:const Text('Monitoring is read-only'),
          trailing:Text('${activities.length} events'),
        )),
        const SizedBox(height:10),
        const Text('Watchlist',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        ...items.map((i)=>Card(child:ListTile(
          title:Text('${i.symbol} • ${i.chain}'),
          subtitle:Text(i.address, maxLines:1,overflow:TextOverflow.ellipsis),
          trailing:Wrap(spacing:4,children:[
            IconButton(tooltip:'Monitor',onPressed:()=>start(i),icon:const Icon(Icons.play_arrow)),
            IconButton(tooltip:'Remove',onPressed:()=>setState(()=>items.remove(i)),icon:const Icon(Icons.delete_outline)),
          ]),
        ))),
        const SizedBox(height:10),
        const Text('Live activity',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        if(activities.isEmpty) const Padding(padding:EdgeInsets.all(20),child:Center(child:Text('No events yet. Start monitoring a token.'))),
        ...activities.take(100).map((a)=>ListTile(
          dense:true,leading:Icon(Icons.circle,size:10,color:levelColor(a.level)),
          title:Text(a.title),subtitle:Text('${a.detail}\n${a.time.toLocal()}'),
        ))
      ])
    )
  );
}
