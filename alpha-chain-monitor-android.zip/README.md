# Alpha Chain Monitor

Read-only Android monitor for BNB Smart Chain and Solana.

## Purpose

Monitor a token contract/mint before it appears on a centralized exchange/Alpha interface and observe whether on-chain activity is actually occurring.

### Current MVP

- BSC contract log WebSocket monitoring
- Solana `logsSubscribe` monitoring
- Watchlist stored locally
- Live activity feed
- Optional BSC liquidity-pool address field
- No wallet connection
- No private keys
- No buy/sell execution
- No automated trading

## Important architecture note

A token contract address alone does not prove that a market exists. The production version should discover and validate liquidity pools and decode DEX-specific `Swap`/pool events before marking a token as "trading".

The app should eventually calculate:

1. Contract active
2. Liquidity pool found
3. Base/quote liquidity present
4. First swap
5. Swaps per 10/30/60 seconds
6. Unique traders
7. Buy/sell volume
8. Liquidity change
9. Sustained activity
10. Risk flags

## RPC configuration

The sample uses public endpoints. For production, make RPC endpoints configurable and use a reliable provider because public endpoints may rate-limit.

## Build with GitHub Actions

The workflow creates the Android platform files with Flutter and builds a release APK.

1. Create a GitHub repository.
2. Upload this folder.
3. Open Actions.
4. Run `Android APK`.
5. Download the generated APK artifact.

## GitHub CLI/manual

This repository is intentionally source-first. You can also run:

```bash
flutter create --platforms=android .
flutter pub get
flutter build apk --release
```

## Safety

This project is intentionally read-only. It does not store seed phrases/private keys and does not execute trades.
