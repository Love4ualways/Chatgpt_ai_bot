# Production architecture

## Mobile
Flutter Android app: watchlist, event feed, token detail, alerts, settings.

## Chain adapters
- BSC/EVM: WebSocket `logs` subscriptions; optional factory/pool discovery; ERC-20 Transfer decoding; DEX-specific Swap decoding.
- Solana: WebSocket `logsSubscribe`; mint/account/program monitoring; DEX-specific instruction decoding.

## Activity state machine
UNKNOWN -> CONTRACT_ACTIVE -> LIQUIDITY_DETECTED -> FIRST_SWAP -> ACTIVE_TRADING -> SUSTAINED_ACTIVITY

Do not mark ACTIVE_TRADING from a Transfer alone.

## Backend recommendation
For many tokens, put WebSocket/RPC monitoring in a small backend service and let the Android app consume normalized events. Mobile-only monitoring can be suspended by Android background restrictions and RPC providers can rate-limit public endpoints.
