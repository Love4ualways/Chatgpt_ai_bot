# Alpha Chain Monitor v3

Fast, read-only Android detector for early on-chain BSC and Solana new-pool activity.

## Detection

- BSC: live PancakeSwap V2 `PairCreated` logs.
- Solana: live `processed` logs for Raydium AMM V4 and Orca Whirlpool, followed by a best-effort `getTransaction` lookup to extract token mints.
- Known-token monitoring for BSC contracts and Solana mints.
- No wallet connection, private keys, buying, selling, or order execution.

## GitHub

Put this ZIP in the repository and run `.github/workflows/android.yml`. The workflow unzips the project, locates `pubspec.yaml`, generates the Android Gradle project with `flutter create`, runs analysis, and builds a release APK.

## Production note

Public BSC/Solana RPC endpoints can be rate-limited. For serious always-on monitoring, replace the public WebSocket/HTTP endpoints with dedicated RPC providers.
