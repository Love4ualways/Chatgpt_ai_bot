# Architecture

The app intentionally prioritizes early observation over trading execution.

BSC WebSocket -> PancakeSwap PairCreated -> new-pool candidate -> dashboard
Solana WebSocket -> Raydium/Orca logs -> transaction lookup -> mint candidate -> dashboard

A candidate is not automatically a confirmed liquid or actively traded market. A later production version should add reserve/liquidity checks, first-swap detection, unique traders, volume, and sustained-activity scoring.
