import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() => runApp(const AlphaMonitorApp());

class Candidate {
  final String chain;
  final String title;
  final String detail;
  final String tx;
  final DateTime time;

  const Candidate({
    required this.chain,
    required this.title,
    required this.detail,
    required this.tx,
    required this.time,
  });
}

class Activity {
  final DateTime time;
  final String title;
  final String detail;
  final String level;

  const Activity(this.time, this.title, this.detail, this.level);
}

class WatchItem {
  final String chain;
  final String address;
  final String symbol;

  const WatchItem({
    required this.chain,
    required this.address,
    required this.symbol,
  });

  Map<String, dynamic> toJson() => {
        'chain': chain,
        'address': address,
        'symbol': symbol,
      };

  factory WatchItem.fromJson(Map<String, dynamic> json) => WatchItem(
        chain: json['chain']?.toString() ?? 'BSC',
        address: json['address']?.toString() ?? '',
        symbol: json['symbol']?.toString() ?? 'TOKEN',
      );
}

class MonitorService {
  WebSocketChannel? _bscWs;
  WebSocketChannel? _solWs;
  final void Function(Activity) onActivity;
  final void Function(Candidate) onCandidate;
  final void Function(String) onStatus;

  MonitorService(this.onActivity, this.onCandidate, this.onStatus);

  static const bscPairCreatedTopic =
      '0x0d3648bd0f6ba80134a33ba9275ac585d9d315f0ad8355cddefde31afa28d0e9';
  static const pancakeV2Factory = '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73';

  static const raydiumAmmV4 = '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8';
  static const orcaWhirlpool = 'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc';

  void stop() {
    _bscWs?.sink.close();
    _solWs?.sink.close();
    _bscWs = null;
    _solWs = null;
  }

  void startFastDiscovery({required String bscWsUrl, required String solWsUrl}) {
    discoverBsc(bscWsUrl);
    discoverSolana(solWsUrl);
  }

  Future<void> discoverBsc(String wsUrl) async {
    try {
      _bscWs?.sink.close();
      onStatus('BSC: connecting to live PairCreated stream…');
      final channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _bscWs = channel;
      channel.sink.add(jsonEncode({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'eth_subscribe',
        'params': [
          'logs',
          {
            'address': pancakeV2Factory,
            'topics': [bscPairCreatedTopic],
          }
        ],
      }));
      channel.stream.listen(
        _handleBsc,
        onError: (_) => onStatus('BSC: WebSocket error — reconnect/restart discovery'),
        onDone: () => onStatus('BSC: WebSocket closed'),
      );
      onStatus('BSC: LIVE — watching new PancakeSwap V2 pairs');
    } catch (e) {
      onStatus('BSC: connection failed — $e');
    }
  }

  void _handleBsc(dynamic raw) {
    try {
      final json = jsonDecode(raw.toString()) as Map<String, dynamic>;
      if (json['method'] != 'eth_subscription') return;
      final result = json['params']?['result'];
      if (result is! Map) return;

      final topics = (result['topics'] as List?)
              ?.map((item) => item.toString())
              .toList() ??
          const <String>[];
      if (topics.length < 3) return;

      final tokenA = _topicAddress(topics[1]);
      final tokenB = _topicAddress(topics[2]);
      final data = result['data']?.toString() ?? '';
      final pair = data.length >= 42 ? '0x${data.substring(data.length - 40)}' : 'unknown';
      final tx = result['transactionHash']?.toString() ?? '';

      onCandidate(Candidate(
        chain: 'BSC',
        title: 'NEW BSC POOL',
        detail: 'PancakeSwap V2 pair detected\n$tokenA ↔ $tokenB\nPool: $pair',
        tx: tx,
        time: DateTime.now(),
      ));
      onActivity(Activity(
        DateTime.now(),
        'BSC new pool detected',
        '$tokenA ↔ $tokenB • pool $pair',
        'good',
      ));
    } catch (_) {
      // Ignore malformed provider messages so one bad message never kills discovery.
    }
  }

  String _topicAddress(String topic) {
    if (topic.length >= 42) return '0x${topic.substring(topic.length - 40)}';
    return topic;
  }

  Future<void> discoverSolana(String wsUrl) async {
    try {
      _solWs?.sink.close();
      onStatus('Solana: connecting to low-latency processed log stream…');
      final channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _solWs = channel;

      final programs = <String>[raydiumAmmV4, orcaWhirlpool];
      for (var i = 0; i < programs.length; i++) {
        channel.sink.add(jsonEncode({
          'jsonrpc': '2.0',
          'id': 100 + i,
          'method': 'logsSubscribe',
          'params': [
            {'mentions': [programs[i]]},
            {'commitment': 'processed'},
          ],
        }));
      }

      channel.stream.listen(
        _handleSolana,
        onError: (_) => onStatus('Solana: WebSocket error — reconnect/restart discovery'),
        onDone: () => onStatus('Solana: WebSocket closed'),
      );
      onStatus('Solana: LIVE — watching Raydium + Orca pool activity');
    } catch (e) {
      onStatus('Solana: connection failed — $e');
    }
  }

  Future<void> _handleSolana(dynamic raw) async {
    try {
      final json = jsonDecode(raw.toString()) as Map<String, dynamic>;
      if (json['method'] != 'logsNotification') return;

      final value = json['params']?['result']?['value'];
      if (value is! Map) return;
      final logs = (value['logs'] as List?)
              ?.map((item) => item.toString())
              .toList() ??
          const <String>[];
      final signature = value['signature']?.toString() ?? '';
      final text = logs.join(' ').toLowerCase();

      final poolLike = text.contains('initialize') ||
          text.contains('create_pool') ||
          text.contains('initialize2') ||
          text.contains('init_pool');
      if (!poolLike || signature.isEmpty) return;

      var detail = 'Pool-initialization activity detected';
      final mints = await _fetchSolanaMints(signature);
      if (mints.isNotEmpty) {
        detail = '$detail\nPossible token mints: ${mints.take(4).join(', ')}';
      }

      onCandidate(Candidate(
        chain: 'Solana',
        title: 'NEW SOLANA POOL CANDIDATE',
        detail: '$detail\nSignature: $signature',
        tx: signature,
        time: DateTime.now(),
      ));
      onActivity(Activity(
        DateTime.now(),
        'Solana new-pool candidate',
        '${mints.isEmpty ? 'Raydium/Orca' : mints.take(2).join(' • ')} • $signature',
        'good',
      ));
    } catch (_) {
      // Keep the real-time stream alive even if an individual transaction is odd.
    }
  }

  Future<List<String>> _fetchSolanaMints(String signature) async {
    try {
      final response = await http.post(
        Uri.parse('https://api.mainnet-beta.solana.com'),
        headers: {'content-type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'id': 1,
          'method': 'getTransaction',
          'params': [
            signature,
            {
              'encoding': 'jsonParsed',
              'commitment': 'processed',
              'maxSupportedTransactionVersion': 0,
            }
          ],
        }),
      );
      if (response.statusCode != 200) return const [];

      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final result = body['result'];
      if (result is! Map) return const [];
      final meta = result['meta'];
      if (meta is! Map) return const [];

      final found = <String>{};
      for (final key in ['preTokenBalances', 'postTokenBalances']) {
        final balances = meta[key];
        if (balances is! List) continue;
        for (final item in balances) {
          if (item is Map && item['mint'] != null) {
            found.add(item['mint'].toString());
          }
        }
      }
      return found.toList();
    } catch (_) {
      return const [];
    }
  }

  Future<void> watchBscToken(String address, String wsUrl) async {
    try {
      _bscWs?.sink.close();
      final channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _bscWs = channel;
      channel.sink.add(jsonEncode({
        'jsonrpc': '2.0',
        'id': 10,
        'method': 'eth_subscribe',
        'params': ['logs', {'address': address}],
      }));
      channel.stream.listen((raw) {
        try {
          final json = jsonDecode(raw.toString());
          if (json['method'] != 'eth_subscription') return;
          final result = json['params']?['result'];
          final tx = result?['transactionHash']?.toString() ?? '';
          onActivity(Activity(DateTime.now(), 'BSC token activity', tx, 'info'));
        } catch (_) {}
      });
      onStatus('BSC token: LIVE contract logs');
    } catch (e) {
      onStatus('BSC token: connection failed — $e');
    }
  }

  Future<void> watchSolanaMint(String mint, String wsUrl) async {
    try {
      _solWs?.sink.close();
      final channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _solWs = channel;
      channel.sink.add(jsonEncode({
        'jsonrpc': '2.0',
        'id': 20,
        'method': 'logsSubscribe',
        'params': [
          {'mentions': [mint]},
          {'commitment': 'processed'},
        ],
      }));
      channel.stream.listen((raw) {
        try {
          final json = jsonDecode(raw.toString());
          if (json['method'] != 'logsNotification') return;
          final value = json['params']?['result']?['value'];
          final signature = value?['signature']?.toString() ?? '';
          final err = value?['err'];
          onActivity(Activity(
            DateTime.now(),
            'Solana mint activity',
            '$mint\n$signature',
            err == null ? 'info' : 'warn',
          ));
        } catch (_) {}
      });
      onStatus('Solana mint: LIVE mentions at processed commitment');
    } catch (e) {
      onStatus('Solana mint: connection failed — $e');
    }
  }
}

class AlphaMonitorApp extends StatefulWidget {
  const AlphaMonitorApp({super.key});

  @override
  State<AlphaMonitorApp> createState() => _AlphaMonitorAppState();
}

class _AlphaMonitorAppState extends State<AlphaMonitorApp> {
  final addressController = TextEditingController();
  final symbolController = TextEditingController(text: 'TOKEN');

  String chain = 'BSC';
  String status = 'Ready';
  bool discoveryOn = false;

  final activities = <Activity>[];
  final candidates = <Candidate>[];
  final watchlist = <WatchItem>[];

  MonitorService? service;

  static const bscWs = 'wss://bsc-rpc.publicnode.com';
  static const solWs = 'wss://api.mainnet-beta.solana.com/';

  @override
  void initState() {
    super.initState();
    _loadWatchlist();
  }

  @override
  void dispose() {
    service?.stop();
    addressController.dispose();
    symbolController.dispose();
    super.dispose();
  }

  Future<void> _loadWatchlist() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('watchlist') ?? const <String>[];
    if (!mounted) return;
    setState(() {
      watchlist.addAll(raw.map((item) => WatchItem.fromJson(jsonDecode(item))));
    });
  }

  Future<void> _saveWatchlist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'watchlist',
      watchlist.map((item) => jsonEncode(item.toJson())).toList(),
    );
  }

  MonitorService _newService() {
    return MonitorService(
      (activity) {
        if (!mounted) return;
        setState(() {
          activities.insert(0, activity);
          if (activities.length > 250) activities.removeLast();
        });
      },
      (candidate) {
        if (!mounted) return;
        setState(() {
          candidates.insert(0, candidate);
          if (candidates.length > 150) candidates.removeLast();
        });
      },
      (newStatus) {
        if (!mounted) return;
        setState(() => status = newStatus);
      },
    );
  }

  void _toggleDiscovery() {
    if (discoveryOn) {
      service?.stop();
      setState(() {
        discoveryOn = false;
        status = 'Live discovery stopped';
      });
      return;
    }

    service?.stop();
    service = _newService();
    service!.startFastDiscovery(bscWsUrl: bscWs, solWsUrl: solWs);
    setState(() => discoveryOn = true);
  }

  void _addWatch() {
    final address = addressController.text.trim();
    if (address.isEmpty) return;
    final symbol = symbolController.text.trim().isEmpty
        ? 'TOKEN'
        : symbolController.text.trim();
    setState(() {
      watchlist.insert(0, WatchItem(chain: chain, address: address, symbol: symbol));
    });
    _saveWatchlist();
    addressController.clear();
  }

  void _watch(WatchItem item) {
    service?.stop();
    service = _newService();
    if (item.chain == 'BSC') {
      service!.watchBscToken(item.address, bscWs);
    } else {
      service!.watchSolanaMint(item.address, solWs);
    }
  }

  void _remove(WatchItem item) {
    setState(() => watchlist.remove(item));
    _saveWatchlist();
  }

  Widget _candidateCard(Candidate candidate) {
    return Card(
      child: ListTile(
        leading: Icon(
          candidate.chain == 'BSC' ? Icons.currency_bitcoin : Icons.bolt,
          color: Colors.amber,
        ),
        title: Text(candidate.title),
        subtitle: Text('${candidate.detail}\n${candidate.time.toLocal()}'),
        isThreeLine: true,
      ),
    );
  }

  Widget _activityTile(Activity activity) {
    final color = activity.level == 'warn'
        ? Colors.orange
        : activity.level == 'good'
            ? Colors.green
            : null;
    return ListTile(
      dense: true,
      leading: Icon(Icons.circle, size: 9, color: color),
      title: Text(activity.title),
      subtitle: Text('${activity.detail}\n${activity.time.toLocal()}'),
      isThreeLine: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Alpha Chain Monitor'),
          actions: [
            IconButton(
              onPressed: () => showAboutDialog(
                context: context,
                applicationName: 'Alpha Chain Monitor',
                applicationVersion: '3.0.0',
                children: const [
                  Text('Fast, read-only BSC and Solana new-pool detector. No wallet and no trading.'),
                ],
              ),
              icon: const Icon(Icons.info_outline),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '⚡ FAST ALPHA NEW-LISTING DETECTOR',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Uses live blockchain WebSockets. BSC watches new PancakeSwap V2 pairs; Solana watches Raydium and Orca pool activity at processed commitment for early detection.',
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: _toggleDiscovery,
                      icon: Icon(discoveryOn ? Icons.stop : Icons.radar),
                      label: Text(
                        discoveryOn ? 'Stop live discovery' : 'START FAST DISCOVERY',
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      status,
                      style: TextStyle(
                        color: discoveryOn ? Colors.greenAccent : null,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            if (candidates.isNotEmpty) ...[
              const Text(
                'NEW ON-CHAIN CANDIDATES',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              ...candidates.take(30).map(_candidateCard),
              const SizedBox(height: 8),
            ],
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'WATCH A KNOWN TOKEN',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'BSC', label: Text('BSC')),
                        ButtonSegment(value: 'SOL', label: Text('Solana')),
                      ],
                      selected: {chain},
                      onSelectionChanged: (selection) {
                        setState(() => chain = selection.first);
                      },
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: symbolController,
                      decoration: const InputDecoration(
                        labelText: 'Symbol',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: addressController,
                      decoration: InputDecoration(
                        labelText: chain == 'BSC' ? 'Token contract' : 'Solana mint',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    FilledButton.icon(
                      onPressed: _addWatch,
                      icon: const Icon(Icons.add),
                      label: const Text('Add to watchlist'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'WATCHLIST',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            if (watchlist.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('No tokens added yet.'),
              )
            else
              ...watchlist.map(
                (item) => Card(
                  child: ListTile(
                    title: Text('${item.symbol} • ${item.chain}'),
                    subtitle: Text(
                      item.address,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Wrap(
                      spacing: 2,
                      children: [
                        IconButton(
                          onPressed: () => _watch(item),
                          icon: const Icon(Icons.play_arrow),
                          tooltip: 'Monitor',
                        ),
                        IconButton(
                          onPressed: () => _remove(item),
                          icon: const Icon(Icons.delete_outline),
                          tooltip: 'Remove',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            const Text(
              'LIVE ACTIVITY',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            if (activities.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Start fast discovery to see live activity.'),
              )
            else
              ...activities.take(60).map(_activityTile),
          ],
        ),
      ),
    );
  }
}
