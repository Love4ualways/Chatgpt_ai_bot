from app.features import heuristic_score

def test_score_range():
    f = {
        "rsi_1m":50,"rsi_accel":0,"ema_slope":0,"macd_hist":0,
        "roc_5":0,"rel_volume":1,"volume_accel":1,"trade_count_accel":1,
        "taker_buy_ratio":0.5,"buy_pressure":0.5,"large_trade_ratio":0,
        "book_imbalance":0,"depth_growth":0,"bb_width":0.03,
        "price_compression":0.03,"mtf_alignment":0,"roc_15":0,
        "spread_bps":50
    }
    assert 0 <= heuristic_score(f) <= 100
