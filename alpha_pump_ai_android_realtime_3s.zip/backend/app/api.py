import json
from fastapi import APIRouter
from app.db.database import db
from app.ml.model import PumpModel

router = APIRouter()
model = PumpModel()

@router.get("/new-listings")
def new_listings(limit: int = 100):
    with db() as con:
        rows = con.execute(
            """
            SELECT alpha_id,symbol,name,chain_name,listing_time,
                   price,liquidity,market_cap,holders,updated_at
            FROM new_listings
            ORDER BY listing_time DESC LIMIT ?
            """,
            (limit,)
        ).fetchall()
    return [dict(row) for row in rows]

@router.get("/pre-pump")
def pre_pump(limit: int = 100):
    with db() as con:
        rows = con.execute(
            """
            SELECT alpha_id,symbol,name,ts,price,heuristic_score,
                   model_probability,prediction_mode,
                   reasons_json,features_json
            FROM prepump
            ORDER BY COALESCE(model_probability,heuristic_score) DESC
            LIMIT ?
            """,
            (limit,)
        ).fetchall()

    result = []
    for row in rows:
        item = dict(row)
        item["reasons"] = json.loads(item.pop("reasons_json"))
        item["features"] = json.loads(item.pop("features_json"))
        item["probability_percent"] = (
            round(item["model_probability"] * 100, 2)
            if item["model_probability"] is not None else None
        )
        result.append(item)
    return result

@router.get("/health")
def health():
    with db() as con:
        listings = con.execute(
            "SELECT COUNT(*) c FROM new_listings"
        ).fetchone()["c"]
        prepump = con.execute(
            "SELECT COUNT(*) c FROM prepump"
        ).fetchone()["c"]
        snapshots = con.execute(
            "SELECT COUNT(*) c FROM snapshots"
        ).fetchone()["c"]

    return {
        "ok": True,
        "new_listings": listings,
        "pre_pump": prepump,
        "snapshots": snapshots,
        "model_ready": model.ready
    }
