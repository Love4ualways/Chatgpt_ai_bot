from __future__ import annotations
import asyncio
import json
import time
import traceback

from app.alpha_api import AlphaAPI
from app.config import settings
from app.db.database import db, init_db
from app.features import calculate_features, heuristic_score
from app.ml.model import PumpModel

class Scanner:
    def __init__(self):
        self.api = AlphaAPI()
        self.model = PumpModel()
        self.previous_depth = {}

    async def close(self):
        await self.api.close()

    async def scan_once(self):
        tokens = await self.api.token_list()
        now = int(time.time() * 1000)
        cutoff = now - settings.new_listing_hours * 3600000

        new = []
        for token in tokens:
            listing_time = int(token.get("listingTime") or 0)
            if listing_time < cutoff or token.get("offline", False):
                continue
            if float(token.get("liquidity") or 0) < settings.min_liquidity_usd:
                continue
            new.append(token)

        with db() as con:
            for t in new:
                con.execute(
                    """
                    INSERT INTO new_listings
                    (alpha_id,symbol,name,chain_name,contract_address,listing_time,
                     price,liquidity,market_cap,holders,first_seen,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(alpha_id) DO UPDATE SET
                    price=excluded.price,
                    liquidity=excluded.liquidity,
                    market_cap=excluded.market_cap,
                    holders=excluded.holders,
                    updated_at=excluded.updated_at
                    """,
                    (
                        t.get("alphaId"), t.get("symbol"), t.get("name"),
                        t.get("chainName"), t.get("contractAddress"),
                        int(t.get("listingTime") or 0),
                        float(t.get("price") or 0),
                        float(t.get("liquidity") or 0),
                        float(t.get("marketCap") or 0),
                        float(t.get("holders") or 0),
                        now, now
                    )
                )

        for t in new:
            try:
                alpha_id = t.get("alphaId")
                if not alpha_id:
                    continue

                symbol = f"{alpha_id}USDT"

                k1, k5, k15, trades, depth = await asyncio.gather(
                    self.api.klines(symbol, "1m", 180),
                    self.api.klines(symbol, "5m", 120),
                    self.api.klines(symbol, "15m", 80),
                    self.api.agg_trades(symbol, 500),
                    self.api.depth(symbol, 50)
                )

                features = calculate_features(
                    k1, k5, k15, trades, depth, t,
                    self.previous_depth.get(symbol)
                )
                score = heuristic_score(features)
                self.previous_depth[symbol] = {
                    "depth_total": features["depth_total"]
                }

                probability = self.model.predict(features)
                mode = "ML" if probability is not None else "HEURISTIC"

                reasons = []
                if features["volume_accel"] > 1.3:
                    reasons.append("volume accelerating")
                if features["buy_pressure"] > 0.58:
                    reasons.append("buy pressure increasing")
                if features["book_imbalance"] > 0.10:
                    reasons.append("bid depth stronger")
                if features["price_compression"] < 0.03:
                    reasons.append("price compressed")
                if features["mtf_alignment"] >= 0.66:
                    reasons.append("multi-timeframe alignment")
                if features["depth_growth"] > 0.05:
                    reasons.append("depth strengthening")
                if features["rsi_accel"] > 2:
                    reasons.append("RSI accelerating")
                if not reasons:
                    reasons.append("mixed early signals")

                qualifies = (
                    probability is not None and
                    probability >= settings.prepump_model_threshold
                ) or (
                    probability is None and
                    score >= settings.prepump_heuristic_threshold
                )

                with db() as con:
                    con.execute(
                        """
                        INSERT INTO snapshots
                        (alpha_id,symbol,ts,price,heuristic_score,features_json)
                        VALUES(?,?,?,?,?,?)
                        """,
                        (
                            alpha_id, symbol, now,
                            float(t.get("price") or 0),
                            score, json.dumps(features)
                        )
                    )

                    if qualifies:
                        con.execute(
                            """
                            INSERT INTO prepump
                            (alpha_id,symbol,name,ts,price,heuristic_score,
                             model_probability,prediction_mode,reasons_json,features_json)
                            VALUES(?,?,?,?,?,?,?,?,?,?)
                            ON CONFLICT(alpha_id) DO UPDATE SET
                            ts=excluded.ts,
                            price=excluded.price,
                            heuristic_score=excluded.heuristic_score,
                            model_probability=excluded.model_probability,
                            prediction_mode=excluded.prediction_mode,
                            reasons_json=excluded.reasons_json,
                            features_json=excluded.features_json
                            """,
                            (
                                alpha_id, symbol, t.get("name"), now,
                                float(t.get("price") or 0), score,
                                probability, mode,
                                json.dumps(reasons),
                                json.dumps(features)
                            )
                        )
                    else:
                        con.execute(
                            "DELETE FROM prepump WHERE alpha_id=?",
                            (alpha_id,)
                        )

            except Exception as exc:
                print(f"[scan] {t.get('alphaId')}: {exc}")

        self._label_old_snapshots(now)
        return {"new_listings": len(new)}

    def _label_old_snapshots(self, now):
        # Labels use only snapshots that occurred AFTER the original observation.
        with db() as con:
            rows = con.execute(
                """
                SELECT id,symbol,ts,price
                FROM snapshots
                WHERE label_ready_15m=0 OR label_ready_60m=0
                ORDER BY ts DESC
                LIMIT 1000
                """
            ).fetchall()

            for row in rows:
                later = con.execute(
                    """
                    SELECT price,ts FROM snapshots
                    WHERE symbol=? AND ts>?
                    ORDER BY ts ASC LIMIT 200
                    """,
                    (row["symbol"], row["ts"])
                ).fetchall()

                if not later:
                    continue

                future15 = [
                    x for x in later
                    if x["ts"] <= row["ts"] + 15 * 60 * 1000
                ]
                future60 = [
                    x for x in later
                    if x["ts"] <= row["ts"] + 60 * 60 * 1000
                ]

                if now >= row["ts"] + 15 * 60 * 1000 and future15:
                    max_price = max(float(x["price"]) for x in future15)
                    min_price = min(float(x["price"]) for x in future15)
                    up = max_price / row["price"] - 1
                    down = min_price / row["price"] - 1
                    label = int(
                        up >= settings.pump_15m_return and
                        down > settings.adverse_move_15m
                    )
                    con.execute(
                        """
                        UPDATE snapshots
                        SET pump_15m=?,label_ready_15m=1
                        WHERE id=?
                        """,
                        (label, row["id"])
                    )

                if now >= row["ts"] + 60 * 60 * 1000 and future60:
                    max_price = max(float(x["price"]) for x in future60)
                    min_price = min(float(x["price"]) for x in future60)
                    up = max_price / row["price"] - 1
                    down = min_price / row["price"] - 1
                    label = int(
                        up >= settings.pump_60m_return and
                        down > settings.adverse_move_60m
                    )
                    con.execute(
                        """
                        UPDATE snapshots
                        SET pump_60m=?,label_ready_60m=1
                        WHERE id=?
                        """,
                        (label, row["id"])
                    )

async def run_forever():
    init_db()
    scanner = Scanner()
    try:
        while True:
            try:
                print(await scanner.scan_once())
            except Exception:
                traceback.print_exc()
            await asyncio.sleep(settings.scan_seconds)
    finally:
        await scanner.close()
