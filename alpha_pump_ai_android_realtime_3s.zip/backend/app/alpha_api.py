import httpx
from app.config import settings

TOKEN_LIST = "/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list"
KLINES = "/bapi/defi/v1/public/alpha-trade/klines"
AGG_TRADES = "/bapi/defi/v1/public/alpha-trade/agg-trades"
DEPTH = "/bapi/defi/v1/public/alpha-trade/fullDepth"
TICKER = "/bapi/defi/v1/public/alpha-trade/ticker"

class AlphaAPI:
    def __init__(self):
        self.base = settings.alpha_base_url.rstrip("/")
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout,
            headers={"User-Agent": "AlphaPumpAI/1.0"}
        )

    async def close(self):
        await self.client.aclose()

    async def _get(self, path, params=None):
        r = await self.client.get(self.base + path, params=params)
        r.raise_for_status()
        payload = r.json()
        if isinstance(payload, dict) and payload.get("success") is False:
            raise RuntimeError(payload.get("message") or "Alpha API request failed")
        return payload.get("data", payload)

    async def token_list(self):
        return await self._get(TOKEN_LIST)

    async def klines(self, symbol, interval="1m", limit=300):
        return await self._get(KLINES, {
            "symbol": symbol, "interval": interval, "limit": limit
        })

    async def agg_trades(self, symbol, limit=500):
        return await self._get(AGG_TRADES, {
            "symbol": symbol, "limit": limit
        })

    async def depth(self, symbol, limit=50):
        return await self._get(DEPTH, {
            "symbol": symbol, "limit": limit
        })

    async def ticker(self, symbol):
        return await self._get(TICKER, {"symbol": symbol})
