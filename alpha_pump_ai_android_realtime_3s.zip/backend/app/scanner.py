import asyncio
from app.services.scanner import run_forever

if __name__ == "__main__":
    asyncio.run(run_forever())
