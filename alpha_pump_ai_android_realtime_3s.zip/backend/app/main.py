from fastapi import FastAPI
from app.db.database import init_db
from app.api import router

app = FastAPI(
    title="Alpha Pump AI API",
    version="1.0.0",
    description="Read-only Alpha market analysis backend."
)
app.include_router(router, prefix="/api")

@app.on_event("startup")
def startup():
    init_db()

@app.get("/")
def root():
    return {"name": "Alpha Pump AI", "paper_analysis_only": True}
