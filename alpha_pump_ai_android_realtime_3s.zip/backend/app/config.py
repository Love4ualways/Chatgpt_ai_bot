from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    alpha_base_url: str = "https://www.binance.com"
    db_path: str = "./alpha_pump.db"
    model_path: str = "./models/pump_model.joblib"
    new_listing_hours: int = 24
    scan_seconds: int = 3
    min_klines: int = 80
    min_liquidity_usd: float = 5000
    prepump_heuristic_threshold: float = 72
    prepump_model_threshold: float = 0.70
    pump_15m_return: float = 0.08
    pump_60m_return: float = 0.15
    adverse_move_15m: float = -0.06
    adverse_move_60m: float = -0.10
    request_timeout: float = 10.0

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
