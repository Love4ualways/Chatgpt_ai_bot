from __future__ import annotations
import math
import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "rsi_1m","rsi_accel","ema9_gap","ema21_gap","ema50_gap","ema_slope",
    "macd_hist","roc_5","roc_15","atr_pct","bb_width","range_compression",
    "rel_volume","volume_accel","trade_count_accel","taker_buy_ratio",
    "buy_pressure","large_trade_ratio","book_imbalance","spread_bps",
    "bid_depth","ask_depth","depth_total","liquidity_mcap","holders_log",
    "volume_mcap","listing_age_hours","change_24h","price_compression",
    "mtf_alignment","depth_growth"
]

def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()

def rsi(s, n=14):
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    down = (-d.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    rs = up / down.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def atr(df, n=14):
    prev = df["close"].shift()
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(n).mean()

def boll_width(s, n=20):
    m = s.rolling(n).mean()
    sd = s.rolling(n).std()
    return (4 * sd) / m.replace(0, np.nan)

def parse_klines(rows):
    out = []
    for x in rows:
        if len(x) < 11:
            continue
        out.append({
            "ts": int(x[0]),
            "open": float(x[1]),
            "high": float(x[2]),
            "low": float(x[3]),
            "close": float(x[4]),
            "volume": float(x[5]),
            "quote_volume": float(x[7]),
            "trades": float(x[8]),
            "taker_buy_base": float(x[9]),
            "taker_buy_quote": float(x[10])
        })
    return pd.DataFrame(out).sort_values("ts").reset_index(drop=True)

def trade_features(rows):
    buy = sell = 0.0
    sizes = []
    for t in rows or []:
        p = float(t["p"])
        q = float(t["q"])
        notional = p * q
        sizes.append(notional)
        # Binance aggregated-trade m=true means buyer is maker.
        # Therefore m=false is an aggressive buyer.
        if bool(t.get("m", False)):
            sell += notional
        else:
            buy += notional
    total = buy + sell
    med = np.median(sizes) if sizes else 0.0
    large = sum(x >= med * 5 for x in sizes) if med > 0 else 0
    return {
        "buy_pressure": buy / total if total else 0.5,
        "large_trade_ratio": large / max(len(sizes), 1)
    }

def depth_features(depth):
    bids = depth.get("bids", []) if isinstance(depth, dict) else []
    asks = depth.get("asks", []) if isinstance(depth, dict) else []
    bid = sum(float(p) * float(q) for p, q in bids[:20])
    ask = sum(float(p) * float(q) for p, q in asks[:20])
    best_bid = float(bids[0][0]) if bids else 0
    best_ask = float(asks[0][0]) if asks else 0
    mid = (best_bid + best_ask) / 2 if best_bid and best_ask else 0
    spread = ((best_ask - best_bid) / mid * 10000) if mid else 999
    total = bid + ask
    return {
        "book_imbalance": (bid - ask) / total if total else 0,
        "spread_bps": spread,
        "bid_depth": bid,
        "ask_depth": ask,
        "depth_total": total
    }

def calculate_features(k1, k5, k15, trades, depth, token, previous=None):
    a = parse_klines(k1)
    b = parse_klines(k5)
    c = parse_klines(k15)

    if len(a) < 30 or len(b) < 20 or len(c) < 10:
        raise ValueError("not enough klines")

    close = a["close"]
    vol = a["volume"]
    e9, e21, e50 = ema(close, 9), ema(close, 21), ema(close, 50)
    rr = rsi(close)
    macd = ema(close, 12) - ema(close, 26)
    signal = ema(macd, 9)
    at = atr(a)
    bw = boll_width(close)

    recent_vol = vol.tail(5).mean()
    baseline = vol.tail(30).head(25).mean()
    relv = recent_vol / baseline if baseline > 0 else 1
    oldv = vol.tail(10).head(5).mean()
    volume_accel = recent_vol / oldv if oldv > 0 else 1

    tc = a["trades"]
    old_tc = tc.tail(10).head(5).mean()
    trade_count_accel = tc.tail(5).mean() / old_tc if old_tc > 0 else 1

    taker_buy = a["taker_buy_base"].tail(5).sum()
    taker_total = a["volume"].tail(5).sum()
    taker_ratio = taker_buy / max(taker_total, 1e-12)

    tf = trade_features(trades)
    df = depth_features(depth)

    price = float(close.iloc[-1])
    range_pct = (a["high"].tail(10).max() - a["low"].tail(10).min()) / max(price, 1e-12)
    short_ranges = ((a["high"] - a["low"]) / a["close"].replace(0, np.nan)).tail(10).mean()

    def align(d):
        cc = d["close"]
        ee9 = ema(cc, 9).iloc[-1]
        ee21 = ema(cc, 21).iloc[-1]
        return 1 if cc.iloc[-1] > ee21 and ee9 > ee21 else 0

    mtf = (align(a) + align(b) + align(c)) / 3

    listing_ms = int(token.get("listingTime") or 0)
    now_ms = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    age_h = max(0, (now_ms - listing_ms) / 3600000) if listing_ms else 9999

    mcap = float(token.get("marketCap") or 0)
    liq = float(token.get("liquidity") or 0)
    holders = float(token.get("holders") or 0)
    vol24 = float(token.get("volume24h") or 0)
    ch24 = float(token.get("percentChange24h") or 0)

    prev_depth = previous or {}
    depth_growth = (
        df["depth_total"] / prev_depth["depth_total"] - 1
        if prev_depth.get("depth_total") else 0
    )

    f = {
        "rsi_1m": float(rr.iloc[-1]),
        "rsi_accel": float(rr.iloc[-1] - rr.iloc[-6]),
        "ema9_gap": float((price / e9.iloc[-1] - 1) * 100),
        "ema21_gap": float((price / e21.iloc[-1] - 1) * 100),
        "ema50_gap": float((price / e50.iloc[-1] - 1) * 100),
        "ema_slope": float((e21.iloc[-1] / e21.iloc[-10] - 1) * 100),
        "macd_hist": float(macd.iloc[-1] - signal.iloc[-1]),
        "roc_5": float((price / close.iloc[-6] - 1) * 100),
        "roc_15": float((price / close.iloc[-16] - 1) * 100),
        "atr_pct": float(at.iloc[-1] / price * 100),
        "bb_width": float(bw.iloc[-1]),
        "range_compression": float(short_ranges),
        "rel_volume": float(relv),
        "volume_accel": float(volume_accel),
        "trade_count_accel": float(trade_count_accel),
        "taker_buy_ratio": float(taker_ratio),
        "buy_pressure": float(tf["buy_pressure"]),
        "large_trade_ratio": float(tf["large_trade_ratio"]),
        "book_imbalance": float(df["book_imbalance"]),
        "spread_bps": float(df["spread_bps"]),
        "bid_depth": float(df["bid_depth"]),
        "ask_depth": float(df["ask_depth"]),
        "depth_total": float(df["depth_total"]),
        "liquidity_mcap": float(liq / max(mcap, 1e-9)),
        "holders_log": float(math.log1p(holders)),
        "volume_mcap": float(vol24 / max(mcap, 1e-9)),
        "listing_age_hours": float(age_h),
        "change_24h": float(ch24),
        "price_compression": float(range_pct),
        "mtf_alignment": float(mtf),
        "depth_growth": float(depth_growth),
    }

    return {
        k: (0.0 if not math.isfinite(v) else v)
        for k, v in f.items()
    }

def heuristic_score(f):
    # Independent factor buckets; traditional indicators cannot dominate the score.
    s = 0
    s += np.clip((f["rsi_1m"] - 45) / 25 * 8, 0, 8)
    s += np.clip(f["rsi_accel"] * 1.5, 0, 7)
    s += np.clip(f["ema_slope"] * 2, 0, 7)
    s += np.clip(f["macd_hist"] / (abs(f["macd_hist"]) + 1e-9) * 5, 0, 5)
    s += np.clip(f["roc_5"] * 0.7, 0, 6)
    s += np.clip((f["rel_volume"] - 1) * 7, 0, 10)
    s += np.clip((f["volume_accel"] - 1) * 8, 0, 10)
    s += np.clip((f["trade_count_accel"] - 1) * 5, 0, 5)
    s += np.clip((f["taker_buy_ratio"] - 0.5) * 25, 0, 7)
    s += np.clip((f["buy_pressure"] - 0.5) * 30, 0, 9)
    s += np.clip(f["large_trade_ratio"] * 8, 0, 5)
    s += np.clip(f["book_imbalance"] * 12, 0, 8)
    s += np.clip(f["depth_growth"] * 8, 0, 5)
    s += np.clip((0.02 - f["bb_width"]) * 100, 0, 5)
    s += np.clip((0.02 - f["price_compression"]) * 100, 0, 5)
    s += f["mtf_alignment"] * 4
    s -= np.clip(f["roc_15"] - 8, 0, 10)
    s -= np.clip((f["spread_bps"] - 100) / 20, 0, 6)
    return float(np.clip(s, 0, 100))
