from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
from app.config import settings
from app.features import FEATURE_NAMES

class PumpModel:
    def __init__(self):
        self.path = Path(settings.model_path)
        self.model = joblib.load(self.path) if self.path.exists() else None

    @property
    def ready(self):
        return self.model is not None

    def predict(self, features):
        if not self.ready:
            return None
        x = np.array(
            [[float(features.get(k, 0)) for k in FEATURE_NAMES]],
            dtype=float
        )
        return float(self.model.predict_proba(x)[0, 1])

    def train(self, X, y):
        if len(X) < 200 or len(set(y)) < 2:
            raise ValueError("Need at least 200 labelled samples and both classes.")

        base = HistGradientBoostingClassifier(
            max_iter=250,
            learning_rate=0.04,
            max_leaf_nodes=15,
            l2_regularization=1.0,
            random_state=42
        )
        model = CalibratedClassifierCV(base, method="sigmoid", cv=3)
        model.fit(X, y)

        self.path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, self.path)
        self.model = model
