import json
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from app.db.database import db, init_db
from app.features import FEATURE_NAMES
from app.ml.model import PumpModel

def main():
    init_db()
    with db() as con:
        rows = con.execute(
            """
            SELECT ts,features_json,pump_60m
            FROM snapshots
            WHERE label_ready_60m=1 AND pump_60m IS NOT NULL
            ORDER BY ts ASC
            """
        ).fetchall()

    if len(rows) < 200:
        print(f"Only {len(rows)} labelled rows. Collect more real data.")
        return

    X = np.array([
        [json.loads(row["features_json"]).get(k, 0) for k in FEATURE_NAMES]
        for row in rows
    ], dtype=float)
    y = np.array([row["pump_60m"] for row in rows], dtype=int)

    split = int(len(rows) * 0.80)
    if len(set(y[:split])) < 2 or len(set(y[split:])) < 2:
        print("Train/holdout split does not contain both classes yet.")
        return

    model = PumpModel()
    model.train(X[:split], y[:split])
    p = model.model.predict_proba(X[split:])[:, 1]

    print("Holdout ROC-AUC:", round(roc_auc_score(y[split:], p), 4))
    print("Holdout PR-AUC:", round(average_precision_score(y[split:], p), 4))
    print("Holdout Brier:", round(brier_score_loss(y[split:], p), 4))
    print("Saved:", model.path)

if __name__ == "__main__":
    main()
