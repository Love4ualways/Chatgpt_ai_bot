import sqlite3
from pathlib import Path
from contextlib import contextmanager
from app.config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS new_listings (
    alpha_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    name TEXT,
    chain_name TEXT,
    contract_address TEXT,
    listing_time INTEGER,
    price REAL,
    liquidity REAL,
    market_cap REAL,
    holders REAL,
    first_seen INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alpha_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    ts INTEGER NOT NULL,
    price REAL NOT NULL,
    heuristic_score REAL NOT NULL,
    features_json TEXT NOT NULL,
    pump_15m INTEGER,
    pump_60m INTEGER,
    label_ready_15m INTEGER NOT NULL DEFAULT 0,
    label_ready_60m INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_snapshots_symbol_ts
ON snapshots(symbol, ts);

CREATE TABLE IF NOT EXISTS prepump (
    alpha_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    name TEXT,
    ts INTEGER NOT NULL,
    price REAL NOT NULL,
    heuristic_score REAL NOT NULL,
    model_probability REAL,
    prediction_mode TEXT NOT NULL,
    reasons_json TEXT NOT NULL,
    features_json TEXT NOT NULL
);
"""

def init_db():
    Path(settings.db_path).parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(settings.db_path) as con:
        con.executescript(SCHEMA)

@contextmanager
def db():
    con = sqlite3.connect(settings.db_path)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()
