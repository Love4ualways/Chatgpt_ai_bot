# Alpha Pump AI design

## New Listings table

Only tokens whose Binance Alpha `listingTime` falls inside `NEW_LISTING_HOURS` are inserted. This table is not the Pre-Pump table.

## Pre-Pump table

A token enters Pre-Pump only when:
- ML probability is at or above `PREPUMP_MODEL_THRESHOLD`, OR
- no real model exists and heuristic score is at or above `PREPUMP_HEURISTIC_THRESHOLD`.

The UI clearly displays whether the result is `ML` or `HEURISTIC`.

## ML labels

The scanner creates labels from future snapshots, not from future information available at prediction time. The default 60-minute label is:

future high >= +15% AND future low > -10%

This is configurable.

## Why this is safer scientifically

A score is not a probability. The system must collect real outcomes, train on an earlier time period, validate on a later time period, and calibrate probabilities before treating the displayed percentage as meaningful.

## Next upgrades

- WebSocket trade/depth stream if supported for the exact Alpha market.
- Persistent Redis cache for API rate control.
- Walk-forward retraining.
- Separate 15m and 60m models.
- Probability calibration on a locked validation period.
- Feature-importance monitoring.
- Slippage/liquidity simulation.
- Alert throttling and duplicate-signal suppression.
