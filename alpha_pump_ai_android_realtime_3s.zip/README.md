# Alpha Pump AI — Android + Python Backend

Paper-analysis only. This project does not place trades or store private keys.

## What it does

1. Reads Binance Alpha public market data.
2. Detects **new Alpha listings** using `listingTime`.
3. Stores them in a dedicated `new_listings` table.
4. Calculates a multi-factor pre-pump feature set:
   - EMA 9/21/50 and slope
   - RSI + RSI acceleration
   - MACD histogram
   - ROC momentum
   - ATR %
   - Bollinger width / price compression
   - relative volume
   - volume acceleration
   - trade-count acceleration
   - taker-buy ratio
   - aggregated-trade buy pressure
   - large-trade ratio
   - order-book imbalance
   - spread and depth
   - liquidity / market-cap
   - holders
   - 24h volume / market-cap
   - listing age
   - multi-timeframe alignment
5. Stores qualifying candidates in a separate **Pre-Pump** table.
6. Collects real snapshots and later creates future outcome labels.
7. Trains a time-ordered ML classifier after enough real labelled data exists.
8. Android displays two separate screens: **New Listings** and **Pre-Pump**.

## Important

Before an ML model has enough real historical data, the app uses `HEURISTIC` mode and shows a score, NOT a fake probability. After a real model is trained, it shows `ML` probability.

No indicator can guarantee a pump.

## Backend

```bash
cd backend
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Run the scanner in another terminal:

```bash
cd backend
.venv\Scripts\activate
python -m app.scanner
```

Train after collecting enough real labelled snapshots:

```bash
python -m app.ml.train
```

API:
- `/health`
- `/api/new-listings`
- `/api/pre-pump`
- `/docs`

## Android

Open `android/` in Android Studio.

- Emulator: `http://10.0.2.2:8080/`
- Physical phone: use the computer's LAN IP, e.g. `http://192.168.1.20:8080/`

Edit:
`android/app/src/main/java/com/alphapump/app/data/ApiConfig.kt`

## Production accuracy work

Use a time-based/walk-forward validation process, probability calibration, a locked test period, and monitor precision/recall/PR-AUC/Brier score. Do not judge the system by a few successful calls.


## Real-time refresh policy

The Android UI now refreshes every **3 seconds**, and the scanner loop is also configured for **3 seconds**.

However, a 3-second REST poll is not truly tick-by-tick real-time. For the fastest pre-pump detection, the production architecture should keep the Android UI at a 3-second refresh while the backend maintains a persistent market-data stream where the exact Alpha market supports it. The backend should aggregate incoming trades/depth into an in-memory cache and expose the latest state to Android. This avoids repeatedly downloading the same history.

The included version therefore uses 3-second polling as the immediate baseline. It does **not** claim that REST polling is a sub-second prediction feed.
