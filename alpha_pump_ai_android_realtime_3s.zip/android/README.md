# Android app

Open this directory in Android Studio.

The app has two independent views:
1. New Listings
2. Pre-Pump

Backend URL:
- Android Emulator: `http://10.0.2.2:8080/`
- Physical phone: use the computer's LAN IP.

This client is read-only and does not place trades.
