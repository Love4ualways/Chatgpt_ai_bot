package com.alphapump.app.data

object ApiConfig {
    // Android emulator:
    const val BASE_URL = "http://10.0.2.2:8080/"
    // Physical phone: replace with the PC's LAN IP, e.g.
    // http://192.168.1.20:8080/
}
