package com.alphapump.app.data

data class NewListing(
    val alpha_id: String,
    val symbol: String,
    val name: String?,
    val chain_name: String?,
    val listing_time: Long,
    val price: Double,
    val liquidity: Double,
    val market_cap: Double,
    val holders: Double,
    val updated_at: Long
)

data class PrePump(
    val alpha_id: String,
    val symbol: String,
    val name: String?,
    val ts: Long,
    val price: Double,
    val heuristic_score: Double,
    val model_probability: Double?,
    val prediction_mode: String,
    val reasons: List<String>,
    val features: Map<String, Double>,
    val probability_percent: Double?
)
