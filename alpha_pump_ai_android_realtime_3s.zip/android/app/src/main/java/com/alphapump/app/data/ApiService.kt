package com.alphapump.app.data

import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("api/new-listings")
    suspend fun newListings(
        @Query("limit") limit: Int = 100
    ): List<NewListing>

    @GET("api/pre-pump")
    suspend fun prePump(
        @Query("limit") limit: Int = 100
    ): List<PrePump>
}
