package com.alphapump.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.alphapump.app.data.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlphaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlphaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var listings by remember { mutableStateOf<List<NewListing>>(emptyList()) }
    var pumps by remember { mutableStateOf<List<PrePump>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        try {
            listings = ApiClient.api.newListings()
            pumps = ApiClient.api.prePump()
            error = null
        } catch (e: Exception) {
            error = e.message ?: "Backend unavailable"
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            refresh()
            delay(3_000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Alpha Bot • AI") })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = {},
                    label = { Text("New Listings") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = {},
                    label = { Text("Pre-Pump") }
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(12.dp)
        ) {
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            if (tab == 0) ListingScreen(listings)
            else PrePumpScreen(pumps)
        }
    }
}

@Composable
fun ListingScreen(items: List<NewListing>) {
    Text("NEW ALPHA LISTINGS", style = MaterialTheme.typography.titleLarge)
    Text("Only recent Alpha listings", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { x ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(x.name ?: x.symbol, style = MaterialTheme.typography.titleMedium)
                    Text("${x.alpha_id} • ${x.chain_name ?: "-"}")
                    Text("Price: ${"%.8f".format(x.price)}")
                    Text(
                        "Liquidity: ${"%,.0f".format(x.liquidity)}   " +
                        "Holders: ${"%,.0f".format(x.holders)}"
                    )
                }
            }
        }
    }
}

@Composable
fun PrePumpScreen(items: List<PrePump>) {
    Text("PRE-PUMP", style = MaterialTheme.typography.titleLarge)
    Text(
        "Separate table • early-move detection",
        style = MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(8.dp))

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { x ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(x.name ?: x.symbol, style = MaterialTheme.typography.titleMedium)
                    Text("${x.alpha_id} • ${x.prediction_mode}")

                    val probability = x.probability_percent
                    if (probability != null) {
                        Text(
                            "AI pump probability: ${"%.1f".format(probability)}%",
                            style = MaterialTheme.typography.titleSmall
                        )
                    } else {
                        Text(
                            "Heuristic score: ${"%.1f".format(x.heuristic_score)}/100",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    Text("Price: ${"%.8f".format(x.price)}")
                    Spacer(Modifier.height(4.dp))
                    x.reasons.take(5).forEach {
                        Text("✓ $it")
                    }
                }
            }
        }
    }
}
