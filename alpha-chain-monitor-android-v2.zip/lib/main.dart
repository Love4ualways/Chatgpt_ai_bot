import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() => runApp(const AlphaMonitorApp());

class Candidate {
  final String chain;
  final String title;
  final String detail;
  final String? tokenA;
  final String? tokenB;
  final String? pool;
  final String tx;
  final DateTime time;
  Candidate({required this.chain, required this.title, required this.detail, required this.tx, required this.time, this.tokenA, this.tokenB, this.pool});
}

class WatchItem {
  final String chain;
  final String address;
  final String symbol;
  WatchItem({required this.chain, required this.address, required this.symbol});
  Map<String, dynamic> toJson() => {'chain': chain, 'address': address, 'symbol': symbol};
  factory WatchItem.fromJson(Map<String, dynamic> j) => WatchItem(chain: j['chain'] ?? 'BSC', address: j['address'] ?? '', symbol: j['symbol'] ?? 'TOKEN');
}

class Activity {
  final DateTime time;
  final String title;
  final String detail;
  final String level;
  Activity(this.time, this.title, this.detail, this.level);
}

class MonitorService {
  WebSocketChannel? _bscWs;
  WebSocketChannel? _solWs;
  final void Function(Activity) onActivity;
  final void Function(Candidate) onCandidate;
  final void Function(String) onStatus;
  MonitorService(this.onActivity, this.onCandidate, this.onStatus);

  void stop() {
    _bscWs?.sink.close();
    _solWs?.sink.close();
    _bscWs = null;
    _solWs = null;
  }

  Future<void> discoverBsc(String wsUrl) async {
    _bscWs?.sink.close();
    onStatus('BSC discovery: connecting…');
    try {
      _bscWs = WebSocketChannel.connect(Uri.parse(wsUrl));
      _bscWs!.sink.add(jsonEncode({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'eth_subscribe',
        'params': [
          'logs',
          {
            'address': '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
            'topics': ['0x0d3648bd0f6ba80134a33ba9275ac585d9d315f0ad8355cddefde31afa28d0e9']
          }
        ]
      }));
      _bscWs!.stream.listen((raw) => _handleBsc(raw), onError: (_) => onStatus('BSC discovery WebSocket error'));
      onStatus('BSC discovery: watching PancakeSwap V2 PairCreated events');
    } catch (e) {
      onStatus('BSC discovery failed: $e');
    }
  }

  void _handleBsc(dynamic raw) {
    try {
      final j = jsonDecode(raw);
      if (j['method'] != 'eth_subscription') return;
      final r = j['params']['result'];
      final topics = (r['topics'] as List?)?.map((e) => e.toString()).toList() ?? [];
      if (topics.length < 3) return;
      final tokenA = _topicAddress(topics[1]);
      final tokenB = _topicAddress(topics[2]);
      final data = (r['data'] ?? '').toString();
      final pair = data.length >= 66 ? '0x${data.substring(data.length - 40)}' : null;
      final tx = r['transactionHash']?.toString() ?? '';
      onCandidate(Candidate(
        chain: 'BSC',
        title: 'New BSC liquidity pair',
        detail: 'PancakeSwap V2 PairCreated detected. $tokenA ↔ $tokenB${pair == null ? '' : ' • pair $pair'}',
        tokenA: tokenA,
        tokenB: tokenB,
        pool: pair,
        tx: tx,
        time: DateTime.now(),
      ));
      onActivity(Activity(DateTime.now(), 'New BSC pair', '$tokenA ↔ $tokenB', 'good'));
    } catch (_) {}
  }

  String _topicAddress(String topic) {
    if (topic.length >= 42) return '0x${topic.substring(topic.length - 40)}';
    return topic;
  }

  Future<void> discoverSolana(String wsUrl) async {
    _solWs?.sink.close();
    onStatus('Solana discovery: connecting…');
    try {
      _solWs = WebSocketChannel.connect(Uri.parse(wsUrl));
      // Raydium AMM v4 + Orca Whirlpool. This is discovery-only: logs are candidates,
      // not proof that a pool is liquid or actively trading.
      final programs = [
        '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
        'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc',
      ];
      for (var i = 0; i < programs.length; i++) {
        _solWs!.sink.add(jsonEncode({
          'jsonrpc': '2.0',
          'id': 100 + i,
          'method': 'logsSubscribe',
          'params': [
            {'mentions': [programs[i]]},
            {'commitment': 'confirmed'}
          ]
        }));
      }
      _solWs!.stream.listen((raw) => _handleSolana(raw), onError: (_) => onStatus('Solana discovery WebSocket error'));
      onStatus('Solana discovery: watching Raydium + Orca pool activity');
    } catch (e) {
      onStatus('Solana discovery failed: $e');
    }
  }

  void _handleSolana(dynamic raw) {
    try {
      final j = jsonDecode(raw);
      if (j['method'] != 'logsNotification') return;
      final value = j['params']['result']['value'];
      final logs = (value['logs'] as List?)?.map((e) => e.toString()).toList() ?? [];
      final sig = value['signature']?.toString() ?? '';
      final joined = logs.join(' ').toLowerCase();
      final looksLikePool = joined.contains('initialize') || joined.contains('create_pool') || joined.contains('initialize2');
      if (!looksLikePool) return;
      final protocol = joined.contains('initialize2') ? 'Raydium' : 'Raydium/Orca';
      onCandidate(Candidate(
        chain: 'Solana',
        title: 'New Solana pool candidate',
        detail: '$protocol initialization-like logs detected. Transaction: $sig',
        tx: sig,
        time: DateTime.now(),
      ));
      onActivity(Activity(DateTime.now(), 'Solana pool candidate', '$protocol • $sig', 'good'));
    } catch (_) {}
  }

  Future<void> watchBscToken(String address, String wsUrl) async {
    _bscWs?.sink.close();
    onStatus('BSC token: connecting…');
    try {
      _bscWs = WebSocketChannel.connect(Uri.parse(wsUrl));
      _bscWs!.sink.add(jsonEncode({'jsonrpc': '2.0', 'id': 1, 'method': 'eth_subscribe', 'params': ['logs', {'address': address}]}));
      _bscWs!.stream.listen((raw) {
        try {
          final j = jsonDecode(raw);
          if (j['method'] == 'eth_subscription') {
            final r = j['params']['result'];
            onActivity(Activity(DateTime.now(), 'BSC contract activity', 'tx ${r['transactionHash']}', 'info'));
          }
        } catch (_) {}
      }, onError: (_) => onStatus('BSC token WebSocket error'));
      onStatus('BSC token: watching contract logs');
    } catch (e) { onStatus('BSC token failed: $e'); }
  }

  Future<void> watchSolanaMint(String mint, String wsUrl) async {
    _solWs?.sink.close();
    onStatus('Solana mint: connecting…');
    try {
      _solWs = WebSocketChannel.connect(Uri.parse(wsUrl));
      _solWs!.sink.add(jsonEncode({'jsonrpc': '2.0', 'id': 1, 'method': 'logsSubscribe', 'params': [{'mentions': [mint]}, {'commitment': 'confirmed'}]}));
      _solWs!.stream.listen((raw) {
        try {
          final j = jsonDecode(raw);
          if (j['method'] == 'logsNotification') {
            final v = j['params']['result']['value'];
            onActivity(Activity(DateTime.now(), 'Solana mint activity', '${mint.substring(0, 8)}… • ${v['signature']}', v['err'] == null ? 'info' : 'warn'));
          }
        } catch (_) {}
      }, onError: (_) => onStatus('Solana mint WebSocket error'));
      onStatus('Solana mint: watching mentions');
    } catch (e) { onStatus('Solana mint failed: $e'); }
  }
}

class AlphaMonitorApp extends StatefulWidget { const AlphaMonitorApp({super.key}); @override State<AlphaMonitorApp> createState() => _AlphaMonitorAppState(); }

class _AlphaMonitorAppState extends State<AlphaMonitorApp> {
  final address = TextEditingController();
  final symbol = TextEditingController(text: 'TOKEN');
  String chain = 'BSC';
  String status = 'Idle';
  final activities = <Activity>[];
  final candidates = <Candidate>[];
  final items = <WatchItem>[];
  MonitorService? service;
  String bscWs = 'wss://bsc-rpc.publicnode.com';
  String solWs = 'wss://api.mainnet-beta.solana.com/';
  bool discoveryOn = false;

  @override void initState() { super.initState(); load(); }
  @override void dispose() { service?.stop(); address.dispose(); symbol.dispose(); super.dispose(); }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('watchlist') ?? [];
    if (mounted) setState(() => items.addAll(raw.map((x) => WatchItem.fromJson(jsonDecode(x)))));
  }
  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('watchlist', items.map((x) => jsonEncode(x.toJson())).toList());
  }
  void add() {
    if (address.text.trim().isEmpty) return;
    setState(() => items.insert(0, WatchItem(chain: chain, address: address.text.trim(), symbol: symbol.text.trim().isEmpty ? 'TOKEN' : symbol.text.trim())));
    save(); address.clear();
  }
  void toggleDiscovery() {
    if (discoveryOn) { service?.stop(); setState(() { discoveryOn = false; status = 'Discovery stopped'; }); return; }
    service?.stop();
    service = MonitorService(
      (a) => setState(() { activities.insert(0, a); if (activities.length > 200) activities.removeLast(); }),
      (c) => setState(() { candidates.insert(0, c); if (candidates.length > 100) candidates.removeLast(); }),
      (s) => setState(() => status = s),
    );
    service!.discoverBsc(bscWs);
    service!.discoverSolana(solWs);
    setState(() => discoveryOn = true);
  }
  void start(WatchItem item) {
    service?.stop();
    service = MonitorService(
      (a) => setState(() { activities.insert(0, a); if (activities.length > 200) activities.removeLast(); }),
      (c) => setState(() { candidates.insert(0, c); if (candidates.length > 100) candidates.removeLast(); }),
      (s) => setState(() => status = s),
    );
    if (item.chain == 'BSC') service!.watchBscToken(item.address, bscWs); else service!.watchSolanaMint(item.address, solWs);
  }

  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.indigo, brightness: Brightness.dark, useMaterial3: true),
    home: Scaffold(
      appBar: AppBar(title: const Text('Alpha Chain Monitor'), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'Alpha Chain Monitor', applicationVersion: '2.0.0', children: const [Text('Fast, read-only BSC and Solana on-chain discovery. It does not connect to wallets or place orders.')]), icon: const Icon(Icons.info_outline))]),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('FAST NEW-LISTING DETECTOR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Watch DEX pool creation activity before a token is surfaced by an exchange interface. Detection is on-chain and read-only.'),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: toggleDiscovery, icon: Icon(discoveryOn ? Icons.stop : Icons.radar), label: Text(discoveryOn ? 'Stop live discovery' : 'Start live discovery')),
          const SizedBox(height: 8),
          Text(status, style: TextStyle(color: discoveryOn ? Colors.greenAccent : null)),
        ]))),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Watch a known token', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          SegmentedButton<String>(segments: const [ButtonSegment(value: 'BSC', label: Text('BSC')), ButtonSegment(value: 'SOL', label: Text('Solana'))], selected: {chain}, onSelectionChanged: (s) => setState(() => chain = s.first)),
          const SizedBox(height: 10),
          TextField(controller: symbol, decoration: const InputDecoration(labelText: 'Symbol', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: address, decoration: InputDecoration(labelText: chain == 'BSC' ? 'Token contract' : 'Solana mint', border: const OutlineInputBorder())),
          const SizedBox(height: 10),
          FilledButton.icon(onPressed: add, icon: const Icon(Icons.add), label: const Text('Add to watchlist')),
        ]))),
        const SizedBox(height: 8),
        if (candidates.isNotEmpty) ...[
          const Text('NEW ON-CHAIN CANDIDATES', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          ...candidates.take(30).map((c) => Card(child: ListTile(leading: Icon(c.chain == 'BSC' ? Icons.currency_bitcoin : Icons.bolt, color: Colors.amber), title: Text('${c.chain} • ${c.title}'), subtitle: Text('${c.detail}\n${c.time.toLocal()}'), isThreeLine: true))),
          const SizedBox(height: 8),
        ],
        const Text('WATCHLIST', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        if (items.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No tokens added yet.')),
        ...items.map((i) => Card(child: ListTile(title: Text('${i.symbol} • ${i.chain}'), subtitle: Text(i.address, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: Wrap(spacing: 2, children: [IconButton(onPressed: () => start(i), icon: const Icon(Icons.play_arrow)), IconButton(onPressed: () { setState(() => items.remove(i)); save(); }, icon: const Icon(Icons.delete_outline))]))),
        const SizedBox(height: 8),
        const Text('LIVE ACTIVITY', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        if (activities.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Start live discovery or monitor a token.')),
        ...activities.take(60).map((a) => ListTile(dense: true, leading: Icon(Icons.circle, size: 9, color: a.level == 'warn' ? Colors.orange : Colors.green), title: Text(a.title), subtitle: Text('${a.detail}\n${a.time.toLocal()}'))),
      ]),
    ),
  );
}
