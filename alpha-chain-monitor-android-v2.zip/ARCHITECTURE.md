# Architecture

```text
BSC WebSocket ──> PancakeSwap V2 PairCreated ──┐
                                               ├─> Candidate feed
Solana WebSocket -> Raydium/Orca logs ─────────┘

Known BSC contract ──> contract logs ──> activity
Known Solana mint ───> logsSubscribe ──> activity
```

The app is intentionally read-only. It does not connect to wallets or execute trades.

## Detection states for the next iteration

1. Candidate detected
2. Pool confirmed
3. Both assets identified
4. Liquidity confirmed
5. First swap confirmed
6. Sustained swaps
7. Unique trader count / volume / liquidity score
