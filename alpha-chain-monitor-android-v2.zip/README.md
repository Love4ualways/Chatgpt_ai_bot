# Alpha Chain Monitor v2

Fast, read-only Android monitor for discovering on-chain DEX activity before a token is surfaced by an exchange UI.

## What changed in v2

- Fixed GitHub Actions build: the workflow now runs `flutter create --platforms=android ... .` before any Android Gradle files are expected.
- Fast live BSC discovery via PancakeSwap V2 `PairCreated` logs.
- Fast Solana discovery via Raydium AMM v4 and Orca Whirlpool log subscriptions.
- Known-token monitoring for BSC contracts and Solana mints.
- Candidate feed and live activity feed.
- No wallet connection, private keys, signing, or order execution.

## GitHub build

Push this repository to GitHub and run **Actions → Build Android APK → Run workflow**. The workflow generates the Android project, fetches dependencies, analyzes the code, builds the release APK, and uploads it as `alpha-chain-monitor-v2-apk`.

## Important detection semantics

A candidate means the monitor observed a DEX/pool-creation-like event. It is **not** a guarantee of liquidity, safety, or active trading. A future backend can enrich each candidate by querying the pool reserves, first swaps, volume, unique traders, and liquidity changes.

## RPC endpoints

The BSC WebSocket endpoint and Solana endpoint are configurable in `lib/main.dart`. Public RPC endpoints can rate-limit. For reliable always-on monitoring, use a dedicated RPC provider.
